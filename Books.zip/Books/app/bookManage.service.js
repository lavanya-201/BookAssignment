myApp.service("bookManage",function(){
    this.bookDetails=[
        { bookId: 1010, bookName: "Mahaswetha", bookAuthor :"sudhaMurthy", 
        descriptionofBook:"The Book is about a girl who is suffering with Leprosy and how she lead her Life",
        Price:"350",
        bookUrl:'D:\\Images\\image1.jpeg'
        },
        { bookId: 1020, bookName: "Her Last Wish", bookAuthor :"Ajay k Pandey", 
        descriptionofBook:"When a Person lost his loved wife suddenly and his friend helped him how to heal",
        Price:"280",
        bookUrl:'image2.jpeg'
        },
        { bookId: 1030, bookName: "5 am Club", bookAuthor :"Robin Sharma", 
        descriptionofBook:"this book is about  when you wake up at 5am ",
        Price:"450",
        bookUrl:'image3.jpeg'
        },
        { bookId: 1040, bookName: "You can win", bookAuthor :"Shiv Kher", 
        descriptionofBook:"Motivational book",
        Price:"550",
        bookUrl:'image4.jpeg'
        },
        { bookId: 1050, bookName: "Three Thousand Stitches", bookAuthor :"SudhaMurthy", 
        descriptionofBook:"Its the simply encourage the courage that touch the lives of others.",
        Price:"150",
        bookUrl:'image5.jpeg'
        },
       ];

    this.getAllbookDetails=function()
    {
        return this.bookDetails;
    }
    this.addBook=function(book)
    {
        this.bookDetails.push(book);
    }

    this.deleteBook=function(book){
        var pos=this.bookDetails.findIndex(item=> {
            if(item.bookId == book.bookId)
            {
                return true;
            }
            else
            {
                return false;
            }
        })

        this.bookDetails.splice(pos,1);
    }


})