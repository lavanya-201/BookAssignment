myApp.controller("BookEditController",function($scope,bookManage){

})
  