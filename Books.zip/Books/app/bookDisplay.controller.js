myApp.controller("bookDisplayController",function($scope,bookManage){
    
    $scope.bookArr=bookManage.getAllbookDetails();
    $scope.addNewBooks=false;
    $scope.showEditBook=false;
    
    $scope.showAddNewBookEventHandler=function(){
       $scope.addNewBooks=true;
    }
 
    $scope.editBookDetailsEventHandler=function(book){
       $scope.selectedBook=book;
       alert("U have selected BookId :"+ book.bookId + " to edit");
       $scope.showEditBook=true;
    }

    $scope.bookSearchArr=bookManage.getAllbookDetails();
    $scope.deleteBookEventHandler=function(bookToBeDeleted)
    {
        bookManage.deleteBook(bookToBeDeleted);
        
    }
})
